This is the 64 bit version of the rxtx driver for windows. 
To be able to use them without getting a warning after compiling you need to replace the 
rxtxcomm.jar file as well as the .dll files