These are all the versions of rxtxcomm.jar and platform dependent libraries. 
Just copy and past the appropriate files into the lib folder in the project folder. 